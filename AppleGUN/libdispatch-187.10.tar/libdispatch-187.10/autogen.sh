#!/bin/sh
autoreconf -fvi
